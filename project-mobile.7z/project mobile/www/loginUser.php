<?php
define('SQL_HOST', 'localhost');
define('SQL_USER', 'smarnmy1');
define('SQL_PASS', 'Sma20405');
define('SQL_DB', 'smarnmy1_uswah');

$conn = mysql_connect(SQL_HOST, SQL_USER, SQL_PASS) or die ('There is a problem with connection to database.'.mysql_error());

mysql_select_db(SQL_DB, $conn) or die ('Could not select database.'.mysql_error());

$ic22=$_POST['ic2'];
$password22=$_POST['password2'];



$sql="SELECT * FROM user WHERE ic='$ic22' AND password='$password22'";
$result = mysql_query($sql);
$row = mysql_num_rows($result);


if($row == 1)
{
    echo json_encode(array('login' => "1"));
} 
else echo json_encode(array('login' => "0"));


//Closes specified connection
mysql_close($conn);
?>