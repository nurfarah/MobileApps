<?php

define('SQL_HOST', 'localhost');
define('SQL_USER', 'smarnmy1');
define('SQL_PASS', 'Sma20405');
define('SQL_DB', 'smarnmy1_uswah');
if(isset($_GET["get_rows"]))
{
    //checks the format client wants
    if($_GET["get_rows"] == "json")
    {
        $conn = mysqli_connect(SQL_HOST, SQL_USER, SQL_PASS, SQL_DB);

        /* check connection */
        if (mysqli_connect_errno()) {
            echo mysqli_connect_error();
            header("HTTP/1.0 500 Internal Server Error");
            exit();
        }
        $mula=$_GET['mula'];
		$jarak=$_GET['jarak'];
        
        $query = "SELECT * FROM jarak WHERE mula='$mula'AND jarak='$jarak'";

        $jsonData = array();

        if ($result = mysqli_query($conn, $query)) {

            /* fetch associative array */
            while ($row = mysqli_fetch_row($result)) {
                $jsonData[] = $row;
            }
            /* free result set */
            mysqli_free_result($result);

            //encode to JSON format
            echo "{\"rows\":". json_encode($jsonData) . "}";
        }
        else {
            echo "{\"rows\":". json_encode($jsonData) . "}";
        }
        /* close connection */
        mysqli_close($conn);
    }
    else
    {
        header("HTTP/1.0 404 Not Found");
    }
}
else
{
    header("HTTP/1.0 404 Not Found");
}
?>