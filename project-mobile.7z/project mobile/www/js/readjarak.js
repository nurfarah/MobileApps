function showjarak() 
{
    var mula = sessionStorage.getItem("mula");
	var tamat = sessionStorage.getItem("tamat");
    alert("jarak= "+jarak);
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://smartgreen.my/uswah/readjarak.php?get_rows=json"+"&jarak="+jarak, false);
    xhr.onload = function(){
        alert(xhr.responseText+" "+xhr.status);
        if(xhr.status == 200)
        {
            var json_string = xhr.responseText;
            var json = JSON.parse(json_string);
            //var out = "test";
            
            var mula = json.rows[0][0];
            var tamat= json.rows[0][1];
            var jarak= json.rows[0][2];
            var status1 = json.rows[0][3];
            alert("jarak: "+jarak);
            
            document.getElementById("mula").value = mula;
            document.getElementById("tamat").value = tamat;
            document.getElementById("jarak").value = jarak;
            document.getElementById("status1").value = status1;
        
            alert("jarak: "+jarak);

        }
        else if (xhr.status == 404)
        {
            alert("Web Service Doesn't Exist", "Error");
        }
        else
        {
            alert("Unknown error occured while connecting to server", "Error");
        }
    }
    xhr.send();
}