function showprofile() 
{
    var prname = sessionStorage.getItem("username2");
    alert("prname= "+prname);
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "http://smartgreen.my/SYUE/readstudent.php?get_rows=json"+"&prname="+prname, false);
    xhr.onload = function(){
        alert(xhr.responseText+" "+xhr.status);
        if(xhr.status == 200)
        {
            var json_string = xhr.responseText;
            var json = JSON.parse(json_string);
            //var out = "test";
            
            var pname = json.rows[0][0];
            var puser = json.rows[0][1];
            var ppass = json.rows[0][2];
            var pemail = json.rows[0][3];
            alert("Name: "+pname);
            
            document.getElementById("prname").value = pname;
            document.getElementById("pruser").value = puser;
            document.getElementById("prpass").value = ppass;
            document.getElementById("premail").value = pemail;
        
            alert("Name: "+pname);

        }
        else if (xhr.status == 404)
        {
            alert("Web Service Doesn't Exist", "Error");
        }
        else
        {
            alert("Unknown error occured while connecting to server", "Error");
        }
    }
    xhr.send();
}