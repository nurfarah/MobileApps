function register(Name,ic,password)
{
    $.ajax({
        type: "POST",
        url: "http://smartgreen.my/uswah/register.php",
        data: "Name="+Name+"&ic="+ic+"&password="+password,
        cache: false,  
        dataType: 'json', 
        success: function(html)
        {
            if(html.register === "1") 
            {
                alert("Thank you!, Registration Done ");
                activate_page("#adminpage");
                
            } 
            else if(html.register === "0")
            {
                alert("Please fill in all the fields.","Registration Failed","Ok");
                
            } 
            else if(html.register === "2")
            {
                alert("Please set password with at least 6 characters.","Registration Failed","Ok");
            
            } 
            else 
            {
                alert(""+html.error,"Error","Ok");
            }
        }
                                        
    }).fail(function(html) {
                                            
            alert("Unable to save data "+html.register,"Error","Ok");
    });
}