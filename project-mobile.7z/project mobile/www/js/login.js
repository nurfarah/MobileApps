function login(ic, password){
    
    $.ajax({
    //	window.alert("xxAJAXxx");
        type: "POST",
        url: "http://smartgreen.my/uswah/loginUser.php",
        data: "ic2="+ic+"&password2="+password,
        cache: false,  
        dataType: 'json', 
        success: function(html)
		{
            if(html.login === "1") 
			{
               alert("Thank you! Log In success ");
            activate_page("#adminpage");
			
                
            } 
			else 
			{
                alert("Username or password is wrong!");
            
            }
        }
                                        
    }).fail(function() {
       alert("failed :)");
            
       
        
    });
    
}

