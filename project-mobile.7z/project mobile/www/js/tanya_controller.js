function submitTanya(){

var data5 = document.getElementById("email").value;
var data6 = document.getElementById("soalan").value;


tanya(data5,data6);
}