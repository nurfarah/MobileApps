/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  #btnadmin */
    $(document).on("click", "#btnadmin", function(evt)
    {
         /*global activate_page */
         activate_page("#admin"); 
         return false;
    });
    
        /* button  #btnMasjid */
    
    
        /* button  #btnMasjid */
    $(document).on("click", "#btnMasjid", function(evt)
    {
         /*global activate_page */
         activate_page("#masjid2"); 
         return false;
    });
    
        /* button  #backmsjd */
    $(document).on("click", "#backmsjd", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btnbackJQ */
    $(document).on("click", "#btnbackJQ", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btnJamak */
    $(document).on("click", "#btnJamak", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btnQasarr */
    $(document).on("click", "#btnQasarr", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btnjmqs */
    $(document).on("click", "#btnjmqs", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btnSolat */
    $(document).on("click", "#btnSolat", function(evt)
    {
         /*global activate_page */
         activate_page("#solatjamak"); 
         return false;
    });
    
        /* button  #JQ1 */
    $(document).on("click", "#JQ1", function(evt)
    {
         /*global activate_page */
         activate_page("#qasar"); 
         return false;
    });
    
        /* button  #JQ2 */
    $(document).on("click", "#JQ2", function(evt)
    {
         /*global activate_page */
         activate_page("#qasar"); 
         return false;
    });
    
        /* button  #JQ3 */
    $(document).on("click", "#JQ3", function(evt)
    {
         /*global activate_page */
         activate_page("#qasar"); 
         return false;
    });
    
        /* button  #QASAR4 */
    $(document).on("click", "#QASAR4", function(evt)
    {
         /*global activate_page */
         activate_page("#qasar"); 
         return false;
    });
    
        /* button  #JAM1 */
    $(document).on("click", "#JAM1", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #JAM2 */
    $(document).on("click", "#JAM2", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #JAM3 */
    $(document).on("click", "#JAM3", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #JAM4 */
    $(document).on("click", "#JAM4", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #QAS1 */
    $(document).on("click", "#QAS1", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #QAS2 */
    $(document).on("click", "#QAS2", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #QAS3 */
    $(document).on("click", "#QAS3", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #QAS4 */
    $(document).on("click", "#QAS4", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #home */
    $(document).on("click", "#home", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btndaftar */
    $(document).on("click", "#btndaftar", function(evt)
    {
         /*global activate_page */
         activate_page("#regitseruser"); 
         return false;
    });
    
        /* button  #logout */
    $(document).on("click", "#logout", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #backreg */
    $(document).on("click", "#backreg", function(evt)
    {
         /*global activate_page */
         activate_page("#adminpage"); 
         return false;
    });
    
        /* button  #backniatzohorJQ */
    $(document).on("click", "#backniatzohorJQ", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #btnniatJQ */
    $(document).on("click", "#btnniatJQ", function(evt)
    {
         /*global activate_page */
         activate_page("#zohorJQ"); 
         return false;
    });
    
        /* button  #backmghribJQ */
    $(document).on("click", "#backmghribJQ", function(evt)
    {
         /*global activate_page */
         activate_page("#jamakqasar"); 
         return false;
    });
    
        /* button  #backmghrib */
    
    
        /* button  #backmghrib */
    $(document).on("click", "#backmghrib", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #btnniatzoho */
    $(document).on("click", "#btnniatzoho", function(evt)
    {
         /*global activate_page */
         activate_page("#zohorJ"); 
         return false;
    });
    
        /* button  #niatmghr */
    $(document).on("click", "#niatmghr", function(evt)
    {
         /*global activate_page */
         activate_page("#maghribJ"); 
         return false;
    });
    
        /* button  #backzoho */
    $(document).on("click", "#backzoho", function(evt)
    {
         /*global activate_page */
         activate_page("#jamak"); 
         return false;
    });
    
        /* button  #mghrib */
    $(document).on("click", "#mghrib", function(evt)
    {
         /*global activate_page */
         activate_page("#maghribJQ"); 
         return false;
    });
    
        /* button  #soalhome */
    
    
        /* button  #soalhome */
    
    
        /* button  #soalhome */
    
    
        /* button  #btnslazim */
    
    
        /* button  #tnyee */
    $(document).on("click", "#tnyee", function(evt)
    {
         /*global activate_page */
         activate_page("#tanya"); 
         return false;
    });
    
        /* button  #btnslazim */
    $(document).on("click", "#btnslazim", function(evt)
    {
         /*global activate_page */
         activate_page("#soalanlazim"); 
         return false;
    });
    
        /* button  #soalhome */
    $(document).on("click", "#soalhome", function(evt)
    {
         /*global activate_page */
         activate_page("#soal"); 
         return false;
    });
    
        /* button  #backustaz */
    
    
        /* button  #backustaz */
    $(document).on("click", "#backustaz", function(evt)
    {
         /*global activate_page */
         activate_page("#soal"); 
         return false;
    });
    
        /* button  #soalhome */
    $(document).on("click", "#soalhome", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btn_sj */
    $(document).on("click", "#btn_sj", function(evt)
    {
         /*global activate_page */
         activate_page("#soal"); 
         return false;
    });
    
        /* button  #backlazim */
    $(document).on("click", "#backlazim", function(evt)
    {
         /*global activate_page */
         activate_page("#soal"); 
         return false;
    });
    
        /* button  #btnsoal1 */
    $(document).on("click", "#btnsoal1", function(evt)
    {
         /*global activate_page */
         activate_page("#soalsatu"); 
         return false;
    });
    
        /* button  #btnsoal6 */
    $(document).on("click", "#btnsoal6", function(evt)
    {
         /*global activate_page */
         activate_page("#soallima"); 
         return false;
    });
    
        /* button  #btnsoal11 */
    $(document).on("click", "#btnsoal11", function(evt)
    {
         /*global activate_page */
         activate_page("#soal11"); 
         return false;
    });
    
        /* button  #btnsoal16 */
    $(document).on("click", "#btnsoal16", function(evt)
    {
         /*global activate_page */
         activate_page("#soal16"); 
         return false;
    });
    
        /* button  #satusoal */
    $(document).on("click", "#satusoal", function(evt)
    {
         /*global activate_page */
         activate_page("#soalanlazim"); 
         return false;
    });
    
        /* button  #soalen */
    $(document).on("click", "#soalen", function(evt)
    {
         /*global activate_page */
         activate_page("#soalanlazim"); 
         return false;
    });
    
        /* button  #sebelas */
    $(document).on("click", "#sebelas", function(evt)
    {
         /*global activate_page */
         activate_page("#soalanlazim"); 
         return false;
    });
    
        /* button  #enambls */
    $(document).on("click", "#enambls", function(evt)
    {
         /*global activate_page */
         activate_page("#soalanlazim"); 
         return false;
    });
    
        /* button  #btn_wktusol */
    $(document).on("click", "#btn_wktusol", function(evt)
    {
         /*global activate_page */
         activate_page("#wakktusolat"); 
         return false;
    });
    
        /* button  #backsolatt */
    $(document).on("click", "#backsolatt", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #homejarak */
    $(document).on("click", "#homejarak", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #btn_jarak */
    $(document).on("click", "#btn_jarak", function(evt)
    {
         /*global activate_page */
         activate_page("#KiraJarak"); 
         return false;
    });
    
        /* button  #btnjaak */
    $(document).on("click", "#btnjaak", function(evt)
    {
         /*global activate_page */
         activate_page("#mainpage"); 
         return false;
    });
    
        /* button  #backk */
    $(document).on("click", "#backk", function(evt)
    {
         /*global activate_page */
         activate_page("#adminpage"); 
         return false;
    });
    
        /* button  #btnsoalll */
    $(document).on("click", "#btnsoalll", function(evt)
    {
         /*global activate_page */
         activate_page("#lsitsoalan"); 
         return false;
    });
    
        /* button  Niat Zohor & Asar */
    
    $(document).on("click", ".uib_w_122", function(evt)
    {
         /*global activate_page */
         activate_page("#zohorJ"); 
         return false;
    });
    
        /* button  Niat Maghrib & Isyak */
    $(document).on("click", ".uib_w_123", function(evt)
    {
         /*global activate_page */
         activate_page("#maghribJ"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);

})();
