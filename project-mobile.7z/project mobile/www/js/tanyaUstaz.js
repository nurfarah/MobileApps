function tanya(email,soalan)
{
    $.ajax({
        type: "POST",
        url: "http://smartgreen.my/uswah/tanya.php",
        data: "email="+email+"&soalan="+soalan,
        cache: false,  
        dataType: 'json', 
        success: function(html)
        {
            if(html.tanya === "1") 
            {
                alert("Terima kasih!, Soalan anda telah selamat dihantar ");
                activate_subpage("#tanyaustaz");
                
            } 
            else if(html.tanya=== "0")
            {
                alert("Please fill in all the fields.","Ok");
                
            } 
            else 
            {
                alert(""+html.error,"Error","Ok");
            }
        }
                                        
    }).fail(function(html) {
                                            
            alert("Unable to save data "+html.tanya,"Error","Ok");
    });
}