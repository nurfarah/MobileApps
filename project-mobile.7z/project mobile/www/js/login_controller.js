function submitLogin() {

  var data11 = document.getElementById("ic2").value;
  var data12 = document.getElementById("password2").value;
  

  login(data11,data12);

  
}