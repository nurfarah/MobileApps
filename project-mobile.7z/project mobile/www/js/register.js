function submitForm(){
var data1 = document.getElementById("Name").value;
var data2 = document.getElementById("ic").value;
var data3 = document.getElementById("password").value;


register(data1,data2,data3);
}

function submitLogin() {

  var data11 = document.getElementById("ic2").value;
  var data12 = document.getElementById("password2").value;
  

  login(data11,data12);

  
}

