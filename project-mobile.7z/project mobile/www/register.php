<?php
define('SQL_HOST', 'localhost');
define('SQL_USER', 'smarnmy1');
define('SQL_PASS', 'Sma20405');
define('SQL_DB', 'smarnmy1_uswah');

$conn = mysql_connect(SQL_HOST, SQL_USER, SQL_PASS) or die ('There is a problem with connection to database.'.mysql_error());

mysql_select_db(SQL_DB, $conn) or die ('Could not select database.'.mysql_error());


$Name = $_POST['Name'];
$ic = $_POST['ic'];
$password = $_POST['password'];

    
if (empty($Name)||empty($ic)||empty($password))
{  
    echo json_encode(array('register' => "0"));   
}

else if(strlen($password)<6)
{
    echo json_encode(array('register' => "2"));

}

else{
    
$sql1="INSERT INTO user (Name, ic, password) VALUES ('$Name', '$ic', '$password')"; 
$exec = mysql_query($sql1, $conn);
    


echo json_encode(array('register' => "1"));
}

mysql_close($conn);

?>